﻿namespace Products.Api.Enums
{
    public enum ProductCategory
    {
        Food = 0,
        Convenience = 1,
        Comodities = 2,
        Durables = 3,
        Digital =4
    }
}
